/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_blogs`; */
/* PRE_TABLE_NAME: `1712121193_wp_blogs`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1712121193_wp_blogs` ( `blog_id` bigint(20) NOT NULL AUTO_INCREMENT, `site_id` bigint(20) NOT NULL DEFAULT '0', `domain` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '', `path` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '', `registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00', `last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00', `public` tinyint(2) NOT NULL DEFAULT '1', `archived` tinyint(2) NOT NULL DEFAULT '0', `mature` tinyint(2) NOT NULL DEFAULT '0', `spam` tinyint(2) NOT NULL DEFAULT '0', `deleted` tinyint(2) NOT NULL DEFAULT '0', `lang_id` int(11) NOT NULL DEFAULT '0', PRIMARY KEY (`blog_id`), KEY `domain` (`domain`(50),`path`(5)), KEY `lang_id` (`lang_id`)) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `1712121193_wp_blogs` (`blog_id`, `site_id`, `domain`, `path`, `registered`, `last_updated`, `public`, `archived`, `mature`, `spam`, `deleted`, `lang_id`) VALUES (1,1,'wp1.local','/','2024-03-26 15:23:25','0000-00-00 00:00:00',1,0,0,0,0,0),(2,1,'test.wp1.local','/','2024-03-26 15:24:35','2024-03-26 15:24:35',1,0,0,0,0,0);
