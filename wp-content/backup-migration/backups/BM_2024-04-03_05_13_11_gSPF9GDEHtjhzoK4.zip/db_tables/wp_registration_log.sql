/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_registration_log`; */
/* PRE_TABLE_NAME: `1712121193_wp_registration_log`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1712121193_wp_registration_log` ( `ID` bigint(20) NOT NULL AUTO_INCREMENT, `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '', `IP` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '', `blog_id` bigint(20) NOT NULL DEFAULT '0', `date_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00', PRIMARY KEY (`ID`), KEY `IP` (`IP`)) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `1712121193_wp_registration_log` (`ID`, `email`, `IP`, `blog_id`, `date_registered`) VALUES (1,'yaswanthkumarbandela@gmail.com','103.99.8.181',2,'2024-03-26 15:24:36');
